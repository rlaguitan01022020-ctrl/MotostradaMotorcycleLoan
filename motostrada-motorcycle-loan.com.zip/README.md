# Motostrada Motorcycle Loan App

## Run locally
1. Install Node.js 18+.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open http://localhost:3000

Demo login: **admin / admin123**. Change this before production use.

## Included
- Login/session authentication with bcrypt password hashing
- CFMOTO series/model/SRP selector using supplied prices
- Manual SRP, DP, interest rate and term overrides
- Add-on interest loan calculator
- Fee lines with % or fixed amount and loan/cash treatment
- NDI and amortization percentage
- Term snapshot for 12/15/18/24/30/36/48 months
- Loan application form
- Requirements page
- Editable Motorcycle Sales Quotation
- Prepared by: Sales Agent on loan summary and quotation
- Browser Print / Save as PDF
- Application form browser save

## Production note
For public deployment, set a strong `SESSION_SECRET`, change the seeded admin password, use HTTPS, and replace the demo user setup with a proper admin/user management flow.
